<a href="startQuiz.php">Welcome click to start a quiz
</a>
